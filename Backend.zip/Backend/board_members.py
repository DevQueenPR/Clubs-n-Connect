from flask import Flask, jsonify, request
from flask_cors import CORS
import mysql.connector as mysql
from config import DATABASE_CONFIG
import os
import sys
from PIL import Image
import logging
import traceback
import shutil
import base64
from werkzeug.utils import secure_filename
import re
from io import BytesIO


app = Flask(__name__)

app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'uploads')  # Ensure this directory exists

CORS(app)

def get_db_connection(): #creating connection to Database
    try:
        conn = mysql.connect(**DATABASE_CONFIG)
        return conn
    except mysql.Error as e:
        print(f"Error connecting to MySQL: {e}")
        sys.exit(1)

#not necesary cause its only by id 
def get_all_boards(): #cambio de nombre
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM board_members")  
        result = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify(result)
    except mysql.Error as e:
        return {"error": f"Error fetching data: {e}"}


def get_board_members(associations_clubs_id): #cambio de nombre
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Query to get the board members along with the association title
        query = """
        SELECT board_members.*, associations_clubs.title 
        FROM board_members
        JOIN associations_clubs ON board_members.associations_clubs_id = associations_clubs.id
        WHERE board_members.associations_clubs_id = %s
        """
        cursor.execute(query, (associations_clubs_id,))
        result = cursor.fetchone()
        cursor.close()
        conn.close()

        # Log the fetched result
        print("Fetched result:", result)  # Debug line

        if result:
            # Get the association title and create a safe_title for the image paths
            safe_title = result['title'].replace(" ", "_")

            # Define the board roles with correct image filenames
            board_roles = {
                'president': 'president.png',
                'vicepresident': 'vicepresident.png',
                'secretary': 'secretary.png',
                'treasurer': 'treasurer.png',
                'vocal_1': 'vocal1.png',
                'vocal_2': 'vocal2.png',
                'vocal_3': 'vocal3.png'
            }
            board_members = []

            # Iterate through roles and add members and image paths
            for role, image_file in board_roles.items():
                role_name = f"{role}_name"
                if role_name in result:
                    # Construct image path for each role using safe_title and corresponding image file
                    image_path = f"https://ot1.ojedatech.com/api/uploads/{safe_title}/board/{image_file}"
                    board_members.append({
                        'role': role,
                        'name': result[role_name],
                        'image': image_path
                    })

            # Return the members and the title in the JSON response
            return jsonify({
                'title': result['title'],  # Include the title in the response
                'members': board_members
            })
        else:
            return jsonify({"error": "No board members found"}), 404

    except mysql.Error as e:
        return jsonify({"error": f"Error fetching data: {e}"}), 500



def new_board():
    try:
        data = request.json
        association_clubs_id = data.get('association_clubs_id')
        president_name = data.get('president_name')
        secretary_name = data.get('secretary_name')
        treasurer_name = data.get('treasurer_name')
        vicepresident_name = data.get('vicepresident_name')
        vocal_1_name = data.get('vocal_1_name')
        vocal_2_name = data.get('vocal_2_name')
        vocal_3_name = data.get('vocal_3_name')

        # Database connection and insert
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            "INSERT INTO board_members (association_clubs_id, president_name, secretary_name, treasurer_name, vicepresident_name, vocal_1_name, vocal_2_name, vocal_3_name) "
            "VALUES(%s, %s, %s, %s, %s, %s, %s, %s)", 
            (association_clubs_id, president_name, secretary_name, treasurer_name, vicepresident_name, vocal_1_name, vocal_2_name, vocal_3_name)
        )
        conn.commit()

        # Image copying logic
        base_path = os.path.join(images_app.config['UPLOAD_FOLDER'], str(association_clubs_id))
        os.makedirs(os.path.join(base_path, 'board'), exist_ok=True)
        board_roles = ['president', 'vicepresident', 'secretary', 'treasurer', 'vocal1', 'vocal2', 'vocal3']
        
        for role in board_roles:
            default_board_path = os.path.join(images_app.config['UPLOAD_FOLDER'], 'default_images', f'{role}.png')
            shutil.copy(default_board_path, os.path.join(base_path, 'board', f'{role}.png'))

        return jsonify({"message": "Board added successfully"}), 201

    except mysql.Error as e:
        conn.rollback()
        return jsonify({"message": str(e)}), 500

    finally:
        cursor.close()
        conn.close()



import os
import re
import base64
from io import BytesIO  # Import BytesIO to handle image byte streams
from PIL import Image  # Import Image from PIL for image processing

def update_board(id):
    conn = None
    cursor = None
    try:
        # Establish database connection
        conn = get_db_connection()
        cursor = conn.cursor()

        # Get the association ID from the request
        associations_clubs_id = id

        # Validate associations_clubs_id
        if not associations_clubs_id:
            return jsonify({"message": "Missing associations_clubs_id"}), 400

        # Fetch association title to create a safe path
        cursor.execute("SELECT title FROM associations_clubs WHERE id = %s", (associations_clubs_id,))
        result = cursor.fetchone()
        if result is None:
            return jsonify({"message": "Association not found"}), 404

        association_title = result[0]
        safe_title = association_title.replace(' ', '_')

        # Process each member's data if provided
        members_data = request.get_json().get("members", [])

        # Mapping roles to filenames without underscores for vocal roles
        filename_map = {
            'vocal_1': 'vocal1.png',
            'vocal_2': 'vocal2.png',
            'vocal_3': 'vocal3.png',
            'president': 'president.png',
            'vicepresident': 'vicepresident.png',
            'secretary': 'secretary.png',
            'treasurer': 'treasurer.png'
        }

        for member in members_data:
            member_role = member.get("role")
            member_name = member.get("name")
            member_image = member.get("image")  # Image data in base64 format or image URL

            # Validate role
            if member_role not in filename_map:
                return jsonify({"message": f"Invalid member role: {member_role}"}), 400

            # Update name if provided
            if member_name:
                cursor.execute(f"""
                    UPDATE board_members 
                    SET {member_role}_name = %s 
                    WHERE associations_clubs_id = %s
                """, (member_name, associations_clubs_id))

            # Save the image if provided
            if member_image and "http" not in member_image:
                # Remove metadata prefix if present
                member_image = re.sub(r"^data:image/\w+;base64,", "", member_image)
                
                # Check length and add padding if necessary
                if len(member_image) % 4 != 0:
                    member_image += "=" * (4 - len(member_image) % 4)  # Add padding
                
                # Validate base64 format
                try:
                    decoded_image = base64.b64decode(member_image)

                    # Resize image using PIL
                    image = Image.open(BytesIO(decoded_image))
                    image.thumbnail((150, 150), Image.LANCZOS)  # Resize while maintaining aspect ratio

                    # Define the correct path and filename
                    filename = filename_map[member_role]
                    member_image_path = os.path.join(app.config['UPLOAD_FOLDER'], safe_title, 'board', filename)
                    os.makedirs(os.path.dirname(member_image_path), exist_ok=True)

                    # Save the image as PNG
                    image.save(member_image_path, format='PNG')
                    
                except Exception as e:
                    return jsonify({"message": f"Failed to save image for {member_role}: {str(e)}"}), 500

        # Commit all changes
        conn.commit()
        return jsonify({
            "success": True,
            "message": "Board updated successfully.",
            "members": members_data
        }), 200

    except Exception as e:
        if conn:
            conn.rollback()
        return jsonify({"message": str(e)}), 500

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()




def delete_board(board_id):
    try:
        
        if not board_id:
            return jsonify({"error": "Board ID is required"}), 400

        # Establish the database connection
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Check if the broadcast exists before attempting to delete
        cursor.execute("SELECT * FROM board_members WHERE id = %s", (board_id,))
        directiva = cursor.fetchone()

        if not directiva:
            return jsonify({"error": "Board not found"}), 404

        # Execute the DELETE statement to remove the broadcast
        cursor.execute("DELETE FROM board_members WHERE id = %s", (board_id,))
        conn.commit()

        return jsonify({"message": "Board deleted successfully"}), 200

    except mysql.connector.Error as e:
        if conn:
            conn.rollback()  # Rollback in case of error
        return jsonify({"error": str(e)}), 500

    finally:
        cursor.close()  # Close the cursor
        conn.close()    # Close the connection
