import mysql.connector as mysql

DATABASE_CONFIG = {
    'host': '192.168.2.192',
    'port': 3306,
    'user': 'remote_user',
    'password': 'RemoteStrongPass#2024',
    'database': 'asociaciones_estudiantiles'
}

def get_db_connection():
    try:
        conn = mysql.connect(**DATABASE_CONFIG)
        return conn
    except mysql.Error as e:
        print(f"Error connecting to MySQL: {e}")
        sys.exit(1)
