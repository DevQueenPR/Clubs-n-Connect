import bcrypt
import shutil
from flask import Flask, jsonify, request
from flask_cors import CORS
from images import app as images_app  
import mysql.connector as mysql 
from werkzeug.utils import secure_filename
from datetime import datetime
from config import DATABASE_CONFIG
import sys
import os
import shutil 
import logging
import io
from PIL import Image

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = '/home/duck/python/uploads'
CORS(app)

def get_db_connection(): #creating connection to Database
    try:
        conn = mysql.connect(**DATABASE_CONFIG)
        return conn
    except mysql.Error as e:
        print(f"Error connecting to MySQL: {e}")
        sys.exit(1)

def get_all_associations(): #cambio de nombre
    try:
        logging.basicConfig(level=logging.INFO)
        logging.info(f"UPLOAD_FOLDER: {app.config['UPLOAD_FOLDER']}")

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM associations_clubs")  
        result = cursor.fetchall()
        cursor.close()
        conn.close()

        # Construct logo image paths for each association
        for asociacion in result:
            safe_title = asociacion['title'].replace(" ", "_")
            logo_path = f"https://ot1.ojedatech.com/api/uploads/{safe_title}/logo/logo.png"  
            asociacion['logo'] = logo_path  

        return jsonify(result)

    except mysql.Error as e:
        return jsonify({"error": f"Error fetching data: {e}"}), 500

def get_association_by_id(association_id): #cambio de nombre
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM associations_clubs WHERE id = %s", (association_id,))
        result = cursor.fetchone()
        conn.close()

        if result:
            # Construct the image paths for logo, news, board, and activities
            safe_title = result['title'].replace(" ", "_")
            base_url = f"https://ot1.ojedatech.com/api/uploads/{safe_title}"

            result['logo'] = f"{base_url}/logo/logo.png"

            return jsonify(result)
        else:
            return jsonify({"error": "Association not found"}), 404

    except mysql.Error as e:
        return jsonify({"error": f"Error fetching data: {e}"}), 500


def new_association():
    conn = None
    try:
        # Fetch the data from the request
        data = request.json
        clasification = data.get('clasification')
        title = data.get('title')
        admin_username = data.get('admin_username')
        admin_password = data.get('admin_password')
        role = data.get('user_type') or 'admin_association'  # Default to 'admin_association' if not provided


        # Validate required fields
        if not clasification or not title or not admin_username or not admin_password:
            return jsonify({"message": "All fields are required"}), 400

        # Convert clasification to an integer
        try:
            clasification = int(clasification)
        except ValueError:
            return jsonify({"message": "Invalid clasification value"}), 400

        if (clasification == 1):
            entity_type = 'la asociación'
        else:
            entity_type = 'el club'

        # Create the dynamic description
        description = f"¡Bienvenidos a {entity_type} de {title}!"

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Check if the association already exists
        cursor.execute("SELECT * FROM associations_clubs WHERE title = %s", (title,))
        existing_association = cursor.fetchone()

        if existing_association:
            return jsonify({"message": "Association already exists"}), 400

        # Hash the admin password
        hashed_password = bcrypt.hashpw(admin_password.encode('utf-8'), bcrypt.gensalt())

        # Create the folder structure for the new association
        safe_title = title.replace(" ", "_")
        base_path = os.path.join(images_app.config['UPLOAD_FOLDER'], safe_title)
        os.makedirs(os.path.join(base_path, 'logo'), exist_ok=True)
        os.makedirs(os.path.join(base_path, 'board'), exist_ok=True)
        os.makedirs(os.path.join(base_path, 'activity'), exist_ok=True)
        os.makedirs(os.path.join(base_path, 'news'), exist_ok=True)

        # Copy the default images (logo, board, activity, news) into the respective folders
        default_logo_path = os.path.join(images_app.config['UPLOAD_FOLDER'], 'default_images', 'logo.png')
        default_activity_path = os.path.join(images_app.config['UPLOAD_FOLDER'], 'default_images', 'activity.png')
        default_news_path = os.path.join(images_app.config['UPLOAD_FOLDER'], 'default_images', 'news.png')

        shutil.copy(default_logo_path, os.path.join(base_path, 'logo', 'logo.png'))
        shutil.copy(default_activity_path, os.path.join(base_path, 'activity', 'activity.png'))
        shutil.copy(default_news_path, os.path.join(base_path, 'news', 'news.png'))

        # Define board roles and default images for each role
        board_roles = ['president', 'vicepresident', 'secretary', 'treasurer', 'vocal1', 'vocal2', 'vocal3']
        for roles in board_roles:
            default_board_path = os.path.join(images_app.config['UPLOAD_FOLDER'], 'default_images', f'{roles}.png')
            shutil.copy(default_board_path, os.path.join(base_path, 'board', f'{roles}.png'))

        # Insert the new association into the database with the description
        cursor.execute(
            "INSERT INTO associations_clubs (clasification, title, description) VALUES (%s, %s, %s)", 
            (clasification, title, description)
        )
        association_id = cursor.lastrowid

        # Insert the new admin associated with the created association
        cursor.execute(
            "INSERT INTO admins (username, password, role, associations_clubs_id) VALUES (%s, %s, %s, %s)",
            (admin_username, hashed_password, role, association_id)
        )

        # Insert the default board members into the 'board_members' table
        cursor.execute(
            "INSERT INTO board_members (president_name, vicepresident_name, secretary_name, treasurer_name, vocal_1_name, vocal_2_name, vocal_3_name, associations_clubs_id) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
            ('Presidente', 'Vice presidente', 'Secretario', 'Tesorero', 'Vocal 1', 'Vocal 2', 'Vocal 3', association_id)
        )
        
        now = datetime.now()
        broadcast_date = now.strftime('%Y-%m-%d')  # MySQL requires YYYY-MM-DD format
        broadcast_time = now.strftime('%H:%M:%S')
        broadcast_title = f"Bienvenidos a {title}"
        broadcast_info = f"¡Esta es la primera transmisión de {title}! Descubre todo lo que {entity_type} de {title} tiene para ti."

        cursor.execute(
            "INSERT INTO broadcast (title, description, broadcast_date, broadcast_time, associations_clubs_id)VALUES (%s, %s, %s, %s, %s) ",
            (broadcast_title, broadcast_info, broadcast_date, broadcast_time, association_id)
        )

        # Commit the changes
        conn.commit()

        return jsonify({"message": "Association, admin, and board members created successfully"}), 201

    except mysql.Error as e:
        if conn is not None:
            conn.rollback()
        return jsonify({"message": str(e)}), 500

    finally:
        if conn is not None:
            conn.close()

def update_association(id):
    conn = get_db_connection()
    cursor = None
    try:
        # Retrieve the old title from the database
        cursor = conn.cursor()
        cursor.execute("SELECT title FROM associations_clubs WHERE id = %s", (id,))
        old_title_row = cursor.fetchone()

        if not old_title_row:
            return jsonify({"message": "Association not found"}), 404

        old_title = old_title_row[0]  # Get the old title
        data = request.form  # Use request.form for text fields

        # New data from the form
        title = data.get('title')
        description = data.get('description')
        clasification = data.get('clasification')
        Facebook = data.get('Facebook')
        Instagram = data.get('Instagram')
        X = data.get('X')

        # Prepare folder names
        old_folder_name = old_title.replace(" ", "_")
        new_folder_name = title.replace(" ", "_") if title else old_folder_name

        # Update the association's metadata in the database
        cursor.execute("""
            UPDATE associations_clubs
            SET title = %s, description = %s, clasification = %s,
                Facebook = %s, Instagram = %s, X = %s
            WHERE id = %s
        """, (title, description, clasification, Facebook, Instagram, X, id))
        conn.commit()

        # Handle folder renaming
        old_folder_path = os.path.join(app.config['UPLOAD_FOLDER'], old_folder_name)
        new_folder_path = os.path.join(app.config['UPLOAD_FOLDER'], new_folder_name)

        if old_folder_name != new_folder_name:
            if os.path.exists(old_folder_path):
                os.rename(old_folder_path, new_folder_path)

        # Check if a new logo image was uploaded
        if 'logo_image' in request.files and request.files['logo_image'].filename:
            logo_image = request.files['logo_image']

            # Resize the image while maintaining aspect ratio
            img = Image.open(logo_image)
            img.thumbnail((500, 500), Image.LANCZOS)  # Use LANCZOS instead of ANTIALIAS

            # Create logo directory if it doesn't exist
            logo_dir = os.path.join(new_folder_path, 'logo')
            os.makedirs(logo_dir, exist_ok=True)

            # Save the resized image
            logo_path = os.path.join(logo_dir, 'logo.png')
            img.save(logo_path, format='PNG')

        # Construct the image URL
        logo_url = f"https://ot1.ojedatech.com/api/uploads/{new_folder_name}/logo/logo.png"

        # Prepare the response data
        result = {
            "title": title,
            "description": description,
            "clasification": clasification,
            "Facebook": Facebook,
            "Instagram": Instagram,
            "X": X,
            "logo": logo_url
        }

        return jsonify(result), 200

    except mysql.Error as e:
        conn.rollback()
        return jsonify({"message": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        conn.close()



def delete_association(association_id):
    conn = None
    try:
        # Validate the provided ID
        if not association_id:
            return jsonify({"message": "Association ID is required"}), 400

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Check if the association exists
        cursor.execute("SELECT * FROM associations_clubs WHERE id = %s", (association_id,))
        association = cursor.fetchone()

        if not association:
            return jsonify({"message": "Association not found"}), 404

        # Get the title to delete the folder
        title = association['title'].replace(" ", "_")
        base_path = os.path.join(images_app.config['UPLOAD_FOLDER'], title)

        # Delete related entries from other tables
        cursor.execute("DELETE FROM board_members WHERE associations_clubs_id = %s", (association_id,))
        cursor.execute("DELETE FROM admins WHERE associations_clubs_id = %s", (association_id,))
        cursor.execute("DELETE FROM broadcast WHERE associations_clubs_id = %s", (association_id,))
        cursor.execute("DELETE FROM calendar WHERE association_id = %s",(association_id,))
        cursor.execute("DELETE FROM associations_clubs WHERE id = %s", (association_id,))

        # Commit the changes
        conn.commit()

        # Delete the folder and all its contents
        if os.path.exists(base_path):
            shutil.rmtree(base_path)

        return jsonify({"message": "Association and related data deleted successfully"}), 200

    except mysql.Error as e:
        if conn is not None:
            conn.rollback()
        return jsonify({"message": str(e)}), 500

    except Exception as e:
        return jsonify({"message": f"Error deleting files: {str(e)}"}), 500

    finally:
        if conn is not None:
            conn.close()


