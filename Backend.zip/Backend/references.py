from flask import Flask, jsonify, request
from flask_cors import CORS
import mysql.connector as mysql
from config import DATABASE_CONFIG
import sys

app = Flask(__name__)
CORS(app)


def get_db_connection(): #creating connection to Database
    try:
        conn = mysql.connect(**DATABASE_CONFIG)
        return conn
    except mysql.Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None 

def get_all_references():
    try:
        conn = get_db_connection()
        if conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM global_references")  
            result = cursor.fetchall()
            cursor.close()
            conn.close()
            return jsonify(result)
        else:
            return jsonify({"error": "Database connection failed"}), 500
    except mysql.Error as e:
        return jsonify({"error": f"Error fetching data: {e}"}), 500

def new_references():
    # Get data from JSON request
    data = request.get_json()
    link_name = data.get('link_name')
    link_url = data.get('link_url')
    
    # Validate required fields
    if not link_name or not link_url:
        return jsonify({"error": "Both 'link_name' and 'link_url' are required"}), 400

    conn = None
    cursor = None
    try:
        # Establish DB connection
        conn = get_db_connection()
        if not conn:
            return jsonify({"error": "Database connection failed"}), 500
        
        cursor = conn.cursor()

        # Insert new reference into the database
        cursor.execute("""
            INSERT INTO global_references (link_name, link_url)
            VALUES (%s, %s)
        """, (link_name, link_url))

        # Commit the transaction
        conn.commit()

        return jsonify({"message": "New reference added successfully"}), 201

    except mysql.Error as e:
        if conn:
            conn.rollback()  # Rollback in case of error
        app.logger.error("Database error occurred: %s", str(e))
        return jsonify({"error": str(e)}), 500

    finally:
        # Ensure that cursor and connection are closed properly
        if cursor:
            cursor.close()
        if conn:
            conn.close()


def update_references(id):
    data = request.get_json()  # Get the JSON body
    link_name = data.get('link_name')
    link_url = data.get('link_url')

    if not id or not link_name or not link_url:
        return jsonify({"error": "ID, Link name, and URL are required"}), 400

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE global_references
            SET link_name = %s, link_url = %s
            WHERE id = %s
        """, (link_name, link_url, id))
        conn.commit()
        return jsonify({"message": "Reference updated successfully"}), 200
    except Exception as e:
        if conn:
            conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()



def delete_references(id):
    try:
        
        if not id:
            return jsonify({"error": "Reference ID is required"}), 400

        # Establish the database connection
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Check if the broadcast exists before attempting to delete
        cursor.execute("SELECT * FROM global_references WHERE id = %s", (id,))
        reference = cursor.fetchone()

        if not reference:
            return jsonify({"error": "Reference not found"}), 404

        # Execute the DELETE statement to remove the broadcast
        cursor.execute("DELETE FROM global_references WHERE id = %s", (id,))
        conn.commit()

        return jsonify({"message": "Reference deleted successfully"}), 200

    except mysql.connector.Error as e:
        if conn:
            conn.rollback()  # Rollback in case of error
        return jsonify({"error": str(e)}), 500

    finally:
        cursor.close()  # Close the cursor
        conn.close()    # Close the connection
if __name__ == '__main__':
    app.run(debug=True)