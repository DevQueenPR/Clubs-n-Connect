from flask import jsonify, request
from config import get_db_connection  # Para conectar a la base de datos

# Obtener todos los eventos filtrados por asociación o club
'''
def get_events(association_id=None):
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        query = "SELECT id, event_title, event_date, description FROM calendar"
        filters = []

        association_id:
 query += " WHERE association_id = %s"
            filters.append(association_id)


        cursor.execute(query, filters)
        events = cursor.fetchall()

        conn.close()
        return jsonify(events)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
'''

# Function to fetch events for a specific association
def get_events(association_id):
    try:
        conn = get_db_connection()  # Ensure your database connection function is defined elsewhere
        cursor = conn.cursor(dictionary=True)

        # Query to fetch events by association_id
        query = "SELECT id, event_title, event_date, description, association_id FROM calendar WHERE association_id = %s"
        filters = [association_id]

        # Execute the query
        cursor.execute(query, filters)
        events = cursor.fetchall()

        # Close the database connection
        conn.close()

        # Return the events as JSON
        return jsonify(events)
    except Exception as e:
        # Log and return the error as JSON
        print(f"Error fetching events: {e}")
        return jsonify({"error": str(e)}), 500

# Function to fetch events for a specific association
def get_event(event_id):
    try:
        conn = get_db_connection()  # Ensure your database connection function is defined elsewhere
        cursor = conn.cursor(dictionary=True)

        # Query to fetch events by association_id
        query = "SELECT id, event_title, event_date, description, association_id FROM calendar WHERE id = %s"
        filters = [event_id]

        # Execute the query
        cursor.execute(query, filters)
        events = cursor.fetchall()

        # Close the database connection
        conn.close()

        # Return the events as JSON
        return jsonify(events)
    except Exception as e:
        # Log and return the error as JSON
        print(f"Error fetching events: {e}")
        return jsonify({"error": str(e)}), 500

# Crear un evento
def new_event():
    try:
        data = request.get_json()
        association_id = data.get('association_id')
        event_title = data.get('event_title')
        event_date = data.get('event_date')
        description = data.get('description')
        

        if not event_title or not event_date or (not association_id):
            return jsonify({"error": "Datos faltantes"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()

        query = """
            INSERT INTO calendar (association_id, event_title, event_date, description)
            VALUES (%s, %s, %s, %s)
        """
        cursor.execute(query, (association_id, event_title, event_date, description))
        conn.commit()
        conn.close()

        return jsonify({"message": "Evento creado exitosamente"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Actualizar un evento
def update_event(id):
    try:
        data = request.get_json()
        event_title = data.get('event_title')
        event_date = data.get('event_date')
        description = data.get('description')

        if not event_title or not event_date:
            return jsonify({"error": "Datos faltantes"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()

        query = """
            UPDATE calendar
            SET event_title = %s, event_date = %s, description = %s
            WHERE id = %s
        """
        cursor.execute(query, (event_title, event_date, description,id))
        conn.commit()
        conn.close()

        return jsonify({"message": "Evento actualizado exitosamente"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Eliminar un evento
def delete_event(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Usa 'id' en lugar de 'event_id'
        query = "DELETE FROM calendar WHERE id = %s"
        cursor.execute(query, (id,))
        conn.commit()
        conn.close()

        return jsonify({"message": "Evento eliminado exitosamente"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
