import bcrypt
from flask import Flask, jsonify, request
from flask_cors import CORS
import mysql.connector as mysql
from mysql.connector import Error
import bcrypt
from config import DATABASE_CONFIG


app = Flask(__name__)
CORS(app)

def get_db_connection(): #creating connection to Database
    try:
        conn = mysql.connect(**DATABASE_CONFIG)
        return conn
    except mysql.Error as e:
        print(f"Error connecting to MySQL: {e}")
        sys.exit(1)

'''
@app.route('/api/login', methods=['POST'])
def login():
    data = request.json  # Asegúrate de que estás obteniendo los datos como JSON

    if not data:
        return jsonify({"message": "No data received"}), 400

    username = data.get('username')  # Usar .get() para evitar errores si la clave no está presente
    password = data.get('password')

    # Valida que ambos campos estén presentes
    if not username or not password:
        return jsonify({"message": "Username and password are required"}), 400

    password = password.encode('utf-8')  # Convertir la contraseña a bytes

    conn = get_db_connection()
    if conn is None:
        return jsonify({"message": "Database connection failed"}), 500

    cursor = conn.cursor(dictionary=True)

    # Obtener al usuario
    cursor.execute("SELECT * FROM admins WHERE username = %s", (username,))
    user = cursor.fetchone()
    conn.close()

    if user:
        stored_password_hash = user['password'].encode('utf-8')  # Contraseña almacenada en la DB

        # Verifica si la contraseña proporcionada coincide con el hash almacenado
        if bcrypt.checkpw(password, stored_password_hash):
            role = user.get('role')
            association_clubs_id = user.get('associations_clubs_id')

            # Imprimir información de depuración
            print(f"Login successful for: {username}, role: {role}, association_clubs_id: {association_clubs_id}")

            # Enviar el rol correctamente formateado
            if role == 'super_admin':
                if association_clubs_id is None:
                    return jsonify({"message": "Login successful", "role": "SuperAdmin", "access": "all_associations", "user": user}), 200
                else:
                    return jsonify({"message": "Login successful", "role": "SuperAdmin", "access": "all_associations", "user": user}), 200
            elif role == 'association_admin':
                # Association admin con acceso a una asociación específica
                return jsonify({"message": "Login successful", "role": "AssociationAdmin", "access": association_clubs_id, "user": user}), 200
            else:
                # Si el rol es inválido
                print(f"Invalid role for user: {username}, role: {role}")
                return jsonify({"message": "Invalid role"}), 403
        else:
            # Contraseña incorrecta
            return jsonify({"message": "Invalid credentials"}), 401
    else:
        # Usuario no encontrado
        return jsonify({"message": "Invalid credentials"}), 401
'''
@app.route('/api/login', methods=['POST'])
def login():
    data = request.json

    if not data:
        return jsonify({"message": "No data received"}), 400

    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({"message": "Username and password are required"}), 400

    password = password.encode('utf-8')
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM admins WHERE username = %s", (username,))
    user = cursor.fetchone()
    conn.close()

    if user:
        stored_password_hash = user['password'].encode('utf-8')

        if bcrypt.checkpw(password, stored_password_hash):
            role = user.get('role')
            association_clubs_id = user.get('associations_clubs_id')

            # Grant all access to both super_admin and association_admin
            if role in ['super_admin', 'association_admin']:
                return jsonify({
                    "message": "Login successful",
                    "role": role,
                    "access": "all_associations",  # Full access for both roles
                    "user": user
                }), 200
            else:
                return jsonify({"message": "Access denied. Please contact support if you believe this is an error."}), 403
        else:
            return jsonify({"message": "Invalid credentials"}), 401
    else:
        return jsonify({"message": "Invalid credentials"}), 401




def new_admin():
    try:
        data = request.json
        print(f"Received data: {data}")

        username = data.get('admin_username')
        password = data.get('admin_password')
        role = data.get('user_type')
        association_id = data.get('association_id')

        conn = None
        cursor = None

        # Validate required fields
        if not username or not password or not role:
            print("Missing fields")
            return jsonify({"message": "Username, password, and role are required"}), 400

        # If role is super_admin, set association_id to None (or 0 based on your logic)
        if role == "super_admin":
            association_id = None  # Or you can leave it as 0 based on your schema

        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        print(f"Hashed password: {hashed_password}")

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        print("Database connection established")

        # Check if the username already exists
        cursor.execute("SELECT * FROM admins WHERE username = %s", (username,))
        existing_admin = cursor.fetchone()

        if existing_admin:
            print("Username already exists")
            return jsonify({"message": "Username already exists"}), 400

        # Insert the new admin
        cursor.execute("""
            INSERT INTO admins (username, password, role, associations_clubs_id) 
            VALUES (%s, %s, %s, %s)
        """, (username, hashed_password, role, association_id))

        conn.commit()

        print("Admin created successfully")
        return jsonify({"message": "Admin created successfully"}), 201

    except mysql.connector.Error as e:
        conn.rollback()
        print(f"Database error: {e}")
        return jsonify({"message": str(e)}), 500

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
        print("Database connection closed")


def get_all_admins():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        query = """
            SELECT 
                admins.id,
                admins.username,
                admins.role,
                admins.associations_clubs_id,
                associations_clubs.title AS association_title
            FROM 
                admins
            LEFT JOIN 
                associations_clubs 
            ON 
                admins.associations_clubs_id = associations_clubs.id
        """
        cursor.execute(query)  
        result = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify(result)
    except mysql.Error as e:
        return {"error": f"Error fetching data: {e}"}


def get_admin_by_id(id):
    try:
        conn = get_db_connection()  # Establish database connection
        cursor = conn.cursor(dictionary=True)  # Use dictionary cursor to return dict-like rows
        cursor.execute("SELECT * FROM admins WHERE id = %s", (id,))  # Fetch specific club by ID
        result = cursor.fetchone()  # Fetch the first row (since we're expecting one result)

        if result:  # Check if any result was returned
            return jsonify(result), 200  # Return the result as JSON
        else:
            return jsonify({"error": "Directiva not found"}), 404  # Return 404 if not found
    except mysql.Error as e:  # Catch any MySQL errors
        return jsonify({"error": f"Error fetching data: {e}"}), 500  # Ensure to return a JSON response
    finally:
        cursor.close()  # Ensure the cursor is closed
        conn.close()  # Ensure the connection is closed

def update_admin(id):
    conn = get_db_connection()
    try:
        data = request.json
        name = data.get('name')
        role = data.get('role')
        password = data.get('password')

        
        cursor = conn.cursor()
        cursor.execute("UPDATE admins SET name = %s, role = %s, password = %s  WHERE id = %s",
                       (name, role, password, id))
        conn.commit()

        return jsonify({"message": "Admin updated"}), 200

    except mysql.Error as e:
        conn.rollback()
        return jsonify({"message": str(e)}), 500
        
    finally:
        cursor.close()
        conn.close()


def delete_admin(admin_id):
    try:
        # Establish the database connection
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Check if the admin exists before attempting to delete
        cursor.execute("SELECT * FROM admins WHERE id = %s", (admin_id,))
        admin = cursor.fetchone()

        if not admin:
            return jsonify({"error": "Admin not found"}), 404

        # Execute the DELETE statement to remove the admin
        cursor.execute("DELETE FROM admins WHERE id = %s", (admin_id,))
        conn.commit()

        return jsonify({"message": "Admin deleted successfully"}), 200

    except mysql.connector.Error as e:
        if conn:
            conn.rollback()  # Rollback in case of error
        return jsonify({"error": str(e)}), 500

    finally:
        cursor.close()  # Close the cursor
        conn.close()    # Close the connection


def reset_admin_password():
    data = request.get_json()
    admin_id = data.get('adminId')
    new_password = data.get('newPassword')

    if not admin_id or not new_password:
        return jsonify({"success": False, "message": "Invalid data provided"}), 400

    # Hash the new password
    hashed_password = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt())

    try:
        # Connect to the MySQL database
        conn = mysql.connect(**DATABASE_CONFIG)
        cursor = conn.cursor()
        # Update the admin password
        cursor.execute("UPDATE admins SET password = %s WHERE id = %s", (hashed_password, admin_id))
        conn.commit()

        if cursor.rowcount == 0:
            return jsonify({"success": False, "message": "Admin not found"}), 404

        return jsonify({"success": True, "message": "Password reset successfully"}), 200

    except mysql.Error as e:
        return jsonify({"success": False, "message": f"Database error: {e}"}), 500

    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()