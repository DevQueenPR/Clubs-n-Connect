from flask import Flask, jsonify, request
import os
import mysql.connector as mysql
from config import DATABASE_CONFIG
from flask_cors import CORS
from werkzeug.utils import secure_filename
from PIL import Image
import logging
import traceback

app = Flask(__name__)
CORS(app)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'uploads')  


def get_db_connection(): #creating connection to Database
    try:
        conn = mysql.connect(**DATABASE_CONFIG)
        return conn
    except mysql.Error as e:
        print(f"Error connecting to MySQL: {e}")
        sys.exit(1)

def get_activity_by_id(association_id):
    activity_images = []

    # Get the association title based on the ID
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Fetch the title from the database
    cursor.execute("SELECT title FROM associations_clubs WHERE id = %s", (association_id,))
    association = cursor.fetchone()

    if not association:
        return jsonify({"error": "Association not found"}), 404

    association_title = association['title']

    # Replace spaces with underscores to match your folder naming convention
    safe_title = association_title.replace(" ", "_")

    # Path to the uploads directory
    associations_folder = app.config['UPLOAD_FOLDER']
    association_path = os.path.join(associations_folder, safe_title)

    # Check if the association folder exists
    if os.path.exists(association_path):
        activity_folder_path = os.path.join(association_path, 'activity')

        # Check if the activity folder exists
        if os.path.exists(activity_folder_path):
            activity_files = [f for f in os.listdir(activity_folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
            activity_image_paths = [f"https://ot1.ojedatech.com/api/uploads/{safe_title}/activity/{img}" for img in activity_files]

            # Prepare the response
            activity_images = {
                'association_title': association_title,
                'activity_images': activity_image_paths
            }
            return jsonify(activity_images)

    # Return an error message if no activity images are found
    return jsonify({"error": "No activity images found for this association"}), 404

def new_activity(association_id):
    # Connect to the database and get the association title
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Fetch the title from the database
    cursor.execute("SELECT title FROM associations_clubs WHERE id = %s", (association_id,))
    association = cursor.fetchone()

    if not association:
        return jsonify({"error": "Association not found"}), 404

    association_title = association['title']
    safe_title = association_title.replace(" ", "_")
    associations_folder = app.config['UPLOAD_FOLDER']
    association_path = os.path.join(associations_folder, safe_title)

    # Create activity folder path
    activity_folder_path = os.path.join(association_path, 'activity')

    # Ensure the activity folder exists
    os.makedirs(activity_folder_path, exist_ok=True)

    # Get existing activity images
    activity_files = [f for f in os.listdir(activity_folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
    activity_image_paths = [f"https://ot1.ojedatech.com/api/uploads/{safe_title}/activity/{img}" for img in activity_files]

    existing_image_path = os.path.join(activity_folder_path, 'activity.png')
    if os.path.exists(existing_image_path):
        os.remove(existing_image_path)

    # Determine the next number for the new image
    max_number = 0
    for f in activity_files:
        # Check if the filename matches the expected pattern
        if f.startswith("activity") and f.split('.')[0][8:].isdigit():  # Check if the part after 'activity' is a digit
            max_number = max(max_number, int(f.split('.')[0][8:]))  # Update max_number based on valid filenames

    new_image_name = f"activity{max_number + 1}.png"  # Default image name for the next activity image

    # **Removed code that deletes existing 'activity.png'**

    # Check if a file was uploaded
    if 'image' in request.files:
        image_file = request.files['image']
        filename = secure_filename(new_image_name)  # Safely name the file
        image_path = os.path.join(activity_folder_path, filename)
        
        # Open the image using Pillow
        with Image.open(image_file) as img:
            # Resize image to 50% of its original dimensions
            new_size = (int(img.width * 0.5), int(img.height * 0.5))
            img = img.resize(new_size, Image.LANCZOS)  # Use LANCZOS instead of ANTIALIAS
            img.save(image_path)  # Save the resized image

        # Append the new image path to the response
        activity_image_paths.append(f"https://ot1.ojedatech.com/api/uploads/{safe_title}/activity/{filename}")

    # Prepare the response with all activity images and the path of the new image
    activity_images = {
        'association_title': association_title,
        'activity_images': activity_image_paths
    }
    
    return jsonify(activity_images)



def delete_activity(association_id, image_name):
    conn = get_db_connection()
    cursor = None
    try:
        cursor = conn.cursor()

        # Debug: Check association ID
        logging.info(f"Deleting image for association_id: {association_id}, image_name: {image_name}")

        # Fetch association title from the database based on association_id
        cursor.execute("SELECT title FROM associations_clubs WHERE id = %s", (association_id,))
        association = cursor.fetchone()

        if not association:
            logging.error("Association not found in the database.")
            return jsonify({"message": "Association not found."}), 404

        # Access title as the first item in the tuple
        association_title = association[0]
        safe_title = association_title.replace(" ", "_")
        logging.info(f"Fetched association title: {association_title}")

        # Path to the uploads directory
        associations_folder = app.config['UPLOAD_FOLDER']
        association_path = os.path.join(associations_folder, safe_title)

        # Debug: Check path
        logging.info(f"Association path: {association_path}")

        # Check if the association folder exists
        if not os.path.exists(association_path):
            logging.error("Association folder not found.")
            return jsonify({"message": "Association folder not found."}), 404

        activity_folder = os.path.join(association_path, 'activity')
        logging.info(f"Activity folder path: {activity_folder}")

        # Check if the news folder exists
        if not os.path.exists(activity_folder):
            logging.error("Activity folder not found.")
            return jsonify({"message": "Activity folder not found."}), 404

        # Construct the full path of the image to be deleted
        image_path = os.path.join(activity_folder, image_name)
        logging.info(f"Image path: {image_path}")

        # Check if the image exists
        if not os.path.isfile(image_path):
            logging.error("Image not found.")
            return jsonify({"message": "Image not found."}), 404

        # Delete the image
        os.remove(image_path)
        logging.info(f"Deleted image: {image_path}")

        # Rename remaining images if needed
        existing_images = sorted([f for f in os.listdir(activity_folder) if f.startswith('activity') and f.endswith(('.png', '.jpg', '.jpeg'))])
        for i, existing_image in enumerate(existing_images, start=1):
            activity_image_name = f'activity{i}.png'
            if existing_image != activity_image_name:
                os.rename(os.path.join(activity_folder, existing_image), os.path.join(activity_folder, new_image_name))
                logging.info(f"Renamed image {existing_image} to {activity_image_name}")

        return jsonify({"message": "Image deleted successfully."}), 200

    except Exception as e:
        logging.error("An error occurred during image deletion:")
        logging.error(traceback.format_exc())
        return jsonify({"message": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        conn.close()