from admin import *  # Esto importará todas las rutas de admin.py
from config import get_db_connection
from flask import Flask, jsonify, request, render_template, redirect, url_for, session
from flask_cors import CORS
import bcrypt
import mysql.connector as mysql
from config import DATABASE_CONFIG
from associations import get_all_associations, get_association_by_id, new_association, update_association, delete_association
from images import create_folder, upload_photo, uploaded_file
from calendar_events import get_events, new_event, update_event, delete_event, get_event
from broadcast import get_all_broadcasts, get_broadcast_by_id, new_broadcast, delete_broadcast, update_broadcast
from datetime import datetime
from board_members import get_all_boards, get_board_members, new_board,  update_board, delete_board
from admin import login, get_all_admins, get_admin_by_id, update_admin, new_admin, delete_admin, reset_admin_password
from news import get_all_news, get_news_by_id, new_news, delete_news
from activity import get_activity_by_id, new_activity, delete_activity
from references import get_all_references, update_references, new_references, delete_references
import sys




app = Flask(__name__)
CORS(app) #Enables CORS for all routes
app.secret_key = 'mlb'

def get_db_connection():
    try:
        conn = mysql.connect(**DATABASE_CONFIG)
        return conn
    except mysql.Error as e:
        print(f"Error connecting to MySQL: {e}")
        sys.exit(1)

# ASOCIACIONES CRUD
@app.route('/api/get_all_associations', methods=['GET'])
def get_all_associations_route():
    return get_all_associations()

@app.route('/api/get_association_by_id/<int:id>', methods=['GET'])
def get_association_route(id):
    return get_association_by_id(id)

@app.route('/api/new_association', methods=['POST'])
def new_association_route():
    return new_association()

@app.route('/api/update_association/<int:id>', methods=['PUT'])
def update_association_route(id):
    return update_association(id)

@app.route('/api/delete_association/<int:id>', methods=['DELETE'])
def delete_association_route(id):
    return delete_association(id)

# BROADCAST CRUD
@app.route('/api/get_all_broadcasts', methods=['GET'])
def get_all_broadcasts_route():
	return get_all_broadcasts()

@app.route('/api/get_broadcast/<int:id>', methods=['GET'])
def get_broadcast_route(id):
    return get_broadcast_by_id(id)

@app.route('/api/new_broadcast', methods=['POST'])
def new_broadcast_route():
    return new_broadcast()

@app.route('/api/update_broadcast/<int:id>', methods=['PUT'])
def update_broadcast_route(id):
    return update_broadcast(id)

@app.route('/api/delete_broadcast/<int:id>', methods=['DELETE'])
def delete_broadcast_route(id):
    return delete_broadcast(id)

#NEWS CRUD
@app.route('/api/get_all_news', methods=['GET'])
def get_all_news_route():
    return get_all_news()

@app.route('/api/get_news_by_id/<int:association_id>', methods=['GET'])
def get_news_by_id_route(association_id):
    return get_news_by_id(association_id)

@app.route('/api/new_news/<int:association_id>', methods=['POST'])
def get_new_news_route(association_id):
    return new_news(association_id)

@app.route('/api/delete_news/<int:association_id>/<string:image_name>', methods=['DELETE'])
def delete_news_route(association_id, image_name):
    return delete_news(association_id, image_name)  # Pass both parameters to the function



#ACTIVITY CRUD
@app.route('/api/get_activity_by_id/<int:association_id>', methods=['GET'])
def get_activity_by_id_route(association_id):
    return get_activity_by_id(association_id)

@app.route('/api/new_activity/<int:association_id>', methods=['POST'])
def new_activity_route(association_id):
    return new_activity(association_id)

@app.route('/api/delete_activity/<int:association_id>/<string:image_name>', methods=['DELETE'])
def delete_activity_route(association_id,image_name):
    return delete_activity(association_id,image_name)

# LOG IN

@app.route('/api/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        data = request.json
        username = data.get('username')
        password = data.get('password')

        if not username or not password:
            return jsonify({"message": "Username and password are required"}), 400

        password = password.encode('utf-8')
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Fetch the user based on the username
        cursor.execute("SELECT * FROM admins WHERE username = %s", (username,))
        user = cursor.fetchone()
        
        if user:
            stored_password_hash = user['password'].encode('utf-8')

            if bcrypt.checkpw(password, stored_password_hash):
                session['username'] = username

                # Send a response regardless of the role
                return jsonify({
                    "message": "Login successful",
                    "role": user.get('role'),
                    "access": user.get('associations_clubs_id', None),  # Include access info if present
                    "user": user
                }), 200
            else:
                return jsonify({"message": "Invalid credentials"}), 401
        else:
            return jsonify({"message": "Invalid credentials"}), 401

        conn.close()
    else:
        return redirect('http://ot1.ojedatech.com:8088/login.html')



@app.route('/api/user')
def user():
    if 'username' in session:
        return redirect('http://ot1.ojedatech.com:8088/admin_panel.html')
    else:
        return redirect('http://ot1.ojedatech.com:8088/login.html')

      



# BOARD CRUD
@app.route('/api/get_all_boards', methods=['GET'])
def get_all_boards_route():
    return get_all_boards()

@app.route('/api/get_board_members/<int:id>', methods=['GET'])
def get_board_members_route(id):
    return get_board_members(id)

@app.route('/api/new_board', methods=['POST'])
def new_board_route():
    return new_board()

@app.route('/api/update_board/<int:id>', methods=['PUT'])
def update_board_route(id):
    return update_board(id)

@app.route('/api/delete_board/<int:id>', methods=['DELETE'])
def delete_board_route(board_id):
    return delete_board(board_id)

# IMAGES
@app.route('/api/images', methods=['GET'])
def images_route():
    return get_images()  # Call the function that fetches images

@app.route('/api/create_folder', methods=['POST'])
def create_folder_route():
    return create_folder()

@app.route('/api/upload_photo', methods=['POST'])
def upload_photo_route():
    return upload_photo()

# Serve files from the uploads folder
@app.route('/uploads/<folder_name>/<subfolder_name>/<filename>')
def uploaded_file_route(folder_name, subfolder_name, filename):
    return uploaded_file(folder_name, subfolder_name, filename)


# ADMINS CRUD
@app.route('/api/get_all_admins', methods=['GET'])
def get_all_admins_route():
    return get_all_admins()  

@app.route('/api/get_admin/<int:id>', methods=['GET'])
def get_admin_route(id):
    return get_admin_by_id(id)

@app.route('/api/update_admin/<int:id>', methods=['PUT'])
def update_admin_route(id):
    return update_admin(id)

@app.route('/api/new_admin', methods=['POST'])
def new_admin_route():
    return new_admin()
    
@app.route('/api/delete_admin/<int:admin_id>', methods=['DELETE'])
def delete_admin_route(admin_id):
    return delete_admin(admin_id)

@app.route('/api/validate', methods=['GET'])
def new_validating_route():
    return validate_credentials()
    
@app.route('/api/reset_admin_password', methods=['PUT'])
def reset_admin_password_route():
    return reset_admin_password() 

# Obtener todas las referencias
@app.route('/api/get_all_references', methods=['GET'])
def get_all_references_route():
    return get_all_references()

@app.route('/api/update_references/<int:id>', methods=['PUT'])
def update_references_route(id):
    return update_references(id) 

@app.route('/api/new_references', methods=['POST'])
def new_references_routed():
    return new_references()

@app.route('/api/delete_references/<int:id>', methods=['DELETE'])
def delete_references_route(id):
    return delete_references(id) 
#dashboard

@app.route('/api/get_dashboard_statistics', methods=['GET'])
def get_dashboard_statistics():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Total de asociaciones
        cursor.execute("SELECT COUNT(*) FROM associations_clubs WHERE clasification = 1")
        total_associations = cursor.fetchone()[0]

        # Total de clubes
        cursor.execute("SELECT COUNT(*) FROM associations_clubs WHERE clasification = 2")
        total_clubs = cursor.fetchone()[0]

        return jsonify({
            "totalAssociations": total_associations,
            "totalClubs": total_clubs
        }), 200

    except mysql.connector.Error as e:
        if conn:
            conn.rollback()  # Rollback in case of error
        return jsonify({"error": str(e)}), 500

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
#EVENTS
@app.route('/api/get_events/<int:association_id>', methods=['GET'])
def get_events_route(association_id):
    return get_events(association_id)
    
@app.route('/api/get_event/<int:event_id>', methods=['GET'])
def get_event_route(event_id):
    return get_event(event_id)

@app.route('/api/new_event', methods=['POST'])
def new_event_route():
    return new_event() 

@app.route('/api/update_event/<int:id>', methods=['PUT'])
def update_event_route(id):
    return update_event(id) 

@app.route('/api/delete_event/<int:id>', methods=['DELETE'])
def delete_event_route(id):
    return delete_event(id) 
    
    

@app.route('/api/home')
def home():
    return redirect('http://ot1.ojedatech.com:8088/index.html')

#if __name__ == '__main__':
#    app.run(debug=True, host='0.0.0.0', port=5000)




app.run(debug=True, host='0.0.0.0', port=5000)
