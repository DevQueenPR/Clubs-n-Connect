from flask import Flask, jsonify, request
from flask_cors import CORS
import mysql.connector as mysql
from config import DATABASE_CONFIG
from datetime import datetime#12 hour format

app = Flask(__name__)
CORS(app)

def get_db_connection(): #creating connection to Database
    try:
        conn = mysql.connect(**DATABASE_CONFIG)
        return conn
    except mysql.Error as e:
        print(f"Error connecting to MySQL: {e}")
        sys.exit(1)


def get_all_broadcasts():
    print("Fetching broadcasts...")  # Confirm function call

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Query to fetch the broadcasts ordered by date and time
        query = """
        SELECT
            b.id,
            b.title,
            b.description,
            TIME_FORMAT(b.broadcast_time, '%h:%i %p') AS broadcast_time, -- Fetch raw time for later formatting
            DATE_FORMAT(b.broadcast_date, '%d %b %Y') AS broadcast_date,
            b.associations_clubs_id,
            a.title AS asociacion_title
        FROM
            broadcast AS b
        JOIN
            associations_clubs AS a ON b.associations_clubs_id = a.id
        ORDER BY
            b.broadcast_date DESC,  -- Sort by broadcast_date
            b.broadcast_time DESC;   -- Then sort by broadcast_time

        """
        
        print(query)
        cursor.execute(query)
        result = cursor.fetchall()
        
        print("Fetched broadcasts:", result)

      
        conn.close()
        return jsonify(result)
    except mysql.Error as e:
        print(f"Error fetching data: {e}")  # Log the error
        return {"error": f"Error fetching data: {e}"}, 500



def get_broadcast_by_id(association_id):
    try:
        # Open DB connection and create cursor
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Ensure an association_id is provided
        if association_id is None:
            return jsonify({"error": "Invalid request: Provide 'association_id'"}), 400

        # Query to get broadcasts by association_clubs_id
        cursor.execute(
        
        """
        SELECT
            b.id,
            b.title,
            b.description,
            TIME_FORMAT(b.broadcast_time, '%h:%i %p') AS broadcast_time, -- Fetch raw time for later formatting
            DATE_FORMAT(b.broadcast_date, '%d %b %Y') AS broadcast_date,
            b.associations_clubs_id,
            a.title AS asociacion_title
        FROM
            broadcast AS b
        JOIN
            associations_clubs AS a ON b.associations_clubs_id = a.id
        WHERE associations_clubs_id  = %s
        ORDER BY
            b.broadcast_date DESC,  -- Sort by broadcast_date
            b.broadcast_time DESC;   -- Then sort by broadcast_time

        """
        , (association_id,))
        
        result = cursor.fetchall()

 
        conn.close()
        return jsonify(result)
    except mysql.Error as e:
        print(f"Error fetching data: {e}")  # Log the error
        return {"error": f"Error fetching data: {e}"}, 500

def new_broadcast():
    cursor = None
    conn = None

    try:
        data = request.json
        title = data.get('title')
        description = data.get('description')
        associations_clubs_id = data.get('associations_clubs_id')  # Extract association ID from the request data
        
        # Check if all required data is provided
        if not title or not description or not associations_clubs_id:
            return jsonify({"message": "Title, description, and association ID are required"}), 400
        
        now = datetime.now()
        broadcast_date = now.strftime('%Y-%m-%d')
        broadcast_time = now.strftime('%H:%M:%S')
        
        conn = get_db_connection() 
        cursor = conn.cursor(dictionary=True) 
        cursor.execute("""
        INSERT INTO broadcast (title, description, broadcast_date, broadcast_time, associations_clubs_id) 
        VALUES (%s, %s, %s, %s, %s)
        """, (title, description, broadcast_date, broadcast_time, associations_clubs_id))  # Include association_id
        conn.commit()

        return jsonify({"message": "Broadcast added successfully"}), 201

    except mysql.Error as e:
        conn.rollback()
        return jsonify({"message": str(e)}), 500
        
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()



def update_broadcast(broadcast_id):
    cursor = None
    conn = None
    try:
        data = request.json
        title = data.get('title')
        description = data.get('description')

        if not title or not description:
            return jsonify({"message": "Title and description are required"}), 400

        # Get the current date and time
        now = datetime.now()
        broadcast_date = now.strftime('%Y-%m-%d')
        broadcast_time = now.strftime('%H:%M:%S')

        # Establish the database connection
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Execute the update query
        cursor.execute("""
            UPDATE broadcast
            SET title = %s, description = %s, broadcast_date = %s, broadcast_time = %s
            WHERE id = %s
        """, (title, description, broadcast_date, broadcast_time, broadcast_id))

        # Commit changes
        conn.commit()

        # Check if any row was updated
        if cursor.rowcount == 0:
            return jsonify({"message": "Broadcast not found"}), 404

        return jsonify({"message": "Broadcast updated successfully"}), 200

    except mysql.Error as e:
        if conn:
            conn.rollback()  # Rollback if there is a database error
        app.logger.error("Database error occurred: %s", str(e))
        return jsonify({"message": str(e)}), 500

    except Exception as e:
        if conn:
            conn.rollback()  # Rollback if there is an unexpected error
        app.logger.error("Unexpected error occurred: %s", str(e))
        return jsonify({"message": "Failed to update broadcast: " + str(e)}), 500

    finally:
        if cursor:
            cursor.close()  # Close the cursor if it was created
        if conn:
            conn.close()  # Close the connection if it was established


def delete_broadcast(broadcast_id):
    try:
        
        if not broadcast_id:
            return jsonify({"error": "Broadcast ID is required"}), 400

        # Establish the database connection
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Check if the broadcast exists before attempting to delete
        cursor.execute("SELECT * FROM broadcast WHERE id = %s", (broadcast_id,))
        broadcast = cursor.fetchone()

        if not broadcast:
            return jsonify({"error": "Broadcast not found"}), 404

        # Execute the DELETE statement to remove the broadcast
        cursor.execute("DELETE FROM broadcast WHERE id = %s", (broadcast_id,))
        conn.commit()

        return jsonify({"message": "Broadcast deleted successfully"}), 200

    except mysql.connector.Error as e:
        if conn:
            conn.rollback()  # Rollback in case of error
        return jsonify({"error": str(e)}), 500

    finally:
        cursor.close()  # Close the cursor
        conn.close()    # Close the connection
