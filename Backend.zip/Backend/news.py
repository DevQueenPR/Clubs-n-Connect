from flask import Flask, jsonify, request
import os
import mysql.connector as mysql
from PIL import Image
from werkzeug.utils import secure_filename
from config import DATABASE_CONFIG
from flask_cors import CORS
import logging 
import traceback


app = Flask(__name__)
CORS(app)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'uploads')  
logging.basicConfig(level=logging.INFO)

def get_db_connection(): #creating connection to Database
    try:
        conn = mysql.connect(**DATABASE_CONFIG)
        return conn
    except mysql.Error as e:
        print(f"Error connecting to MySQL: {e}")
        sys.exit(1)

def get_all_news():
    all_association_images = []

    # List all associations in the uploads directory
    associations_folder = app.config['UPLOAD_FOLDER']
    
    if not os.path.exists(associations_folder):
        return jsonify({"error": "Uploads folder not found"}), 404

    # Iterate through each association's folder
    for association_folder in os.listdir(associations_folder):
        association_path = os.path.join(associations_folder, association_folder)

        if os.path.isdir(association_path):  # Check if it's a directory
            # Path to the news folder for the association
            news_folder_path = os.path.join(association_path, 'news')

            if os.path.exists(news_folder_path):
                # Get all images in the news folder
                news_images = [img for img in os.listdir(news_folder_path) if img.endswith(('.png', '.jpg', '.jpeg'))]

                # Create paths for the images
                news_image_paths = [f"https://ot1.ojedatech.com/api/uploads/{association_folder}/news/{img}" for img in news_images]

                # Append the association and its images to the list
                all_association_images.append({
                    'association_title': association_folder, 
                    'news_images': news_image_paths
                })

    if not all_association_images:
        return jsonify({"error": "No associations found"}), 404

    return jsonify(all_association_images)


def get_news_by_id(association_id):
    news_images = []

    # Get the association title based on the ID
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Fetch the title from the database
    cursor.execute("SELECT title FROM associations_clubs WHERE id = %s", (association_id,))
    association = cursor.fetchone()

    if not association:
        return jsonify({"error": "Association not found"}), 404

    association_title = association['title']

    # Replace spaces with underscores to match your folder naming convention
    safe_title = association_title.replace(" ", "_")

    # Path to the uploads directory
    associations_folder = app.config['UPLOAD_FOLDER']
    association_path = os.path.join(associations_folder, safe_title)

    # Check if the association folder exists
    if os.path.exists(association_path):  
        news_folder_path = os.path.join(association_path, 'news')

        # Check if the news folder exists
        if os.path.exists(news_folder_path):
            news_files = [f for f in os.listdir(news_folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
            news_image_paths = [f"https://ot1.ojedatech.com/api/uploads/{safe_title}/news/{img}" for img in news_files]

            # Prepare the response
            news_images = {
                'association_title': association_title,
                'news_images': news_image_paths
            }
            return jsonify(news_images)

    # Return an error message if the association is not found
    return jsonify({"error": "No news found for this association"}), 404

def new_news(association_id):
    # Connect to the database and get the association title
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Fetch the title from the database
    cursor.execute("SELECT title FROM associations_clubs WHERE id = %s", (association_id,))
    association = cursor.fetchone()

    if not association:
        return jsonify({"error": "Association not found"}), 404

    association_title = association['title']
    safe_title = association_title.replace(" ", "_")
    associations_folder = app.config['UPLOAD_FOLDER']
    association_path = os.path.join(associations_folder, safe_title)

    # Create news folder path
    news_folder_path = os.path.join(association_path, 'news')

    # Ensure the news folder exists
    os.makedirs(news_folder_path, exist_ok=True)

    # Get existing news images
    news_files = [f for f in os.listdir(news_folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
    news_image_paths = [f"https://ot1.ojedatech.com/api/uploads/{safe_title}/news/{img}" for img in news_files]
    
    # Determine the next number for the new image
    max_number = 0
    for f in news_files:
        # Check if the filename matches the expected pattern
        if f.startswith("news") and f.split('.')[0][4:].isdigit():  # Check if the part after 'news' is a digit
            max_number = max(max_number, int(f.split('.')[0][4:]))  # Update max_number based on valid filenames

    new_image_name = f"news{max_number + 1}.png"  # Default image name
    
     # Check if a file named 'news.png' exists and delete it if it does
    existing_image_path = os.path.join(news_folder_path, 'news.png')
    if os.path.exists(existing_image_path):
        os.remove(existing_image_path)  # Delete the existing 'news.png'

    # Check if a file was uploaded
    if 'image' in request.files:
        image_file = request.files['image']
        filename = secure_filename(new_image_name)  # Safely name the file
        image_path = os.path.join(news_folder_path, filename)
        
        # Open the image using Pillow
        with Image.open(image_file) as img:
            # Resize image to 50% of its original dimensions
            new_size = (int(img.width * 0.5), int(img.height * 0.5))
            img = img.resize(new_size, Image.LANCZOS)  # Use LANCZOS instead of ANTIALIAS
            img.save(image_path)  # Save the resized image


        # Append the new image path to the response
        news_image_paths.append(f"https://ot1.ojedatech.com/api/uploads/{safe_title}/news/{filename}")

    # Prepare the response with all news images and the path of the new image
    news_images = {
        'association_title': association_title,
        'news_images': news_image_paths
    }
    
    return jsonify(news_images)


def delete_news(association_id, image_name):
    conn = get_db_connection()
    cursor = None
    try:
        cursor = conn.cursor()

        # Debug: Check association ID
        logging.info(f"Deleting image for association_id: {association_id}, image_name: {image_name}")

        # Fetch association title from the database based on association_id
        cursor.execute("SELECT title FROM associations_clubs WHERE id = %s", (association_id,))
        association = cursor.fetchone()

        if not association:
            logging.error("Association not found in the database.")
            return jsonify({"message": "Association not found."}), 404

        # Access title as the first item in the tuple
        association_title = association[0]
        safe_title = association_title.replace(" ", "_")
        logging.info(f"Fetched association title: {association_title}")

        # Path to the uploads directory
        associations_folder = app.config['UPLOAD_FOLDER']
        association_path = os.path.join(associations_folder, safe_title)

        # Debug: Check path
        logging.info(f"Association path: {association_path}")

        # Check if the association folder exists
        if not os.path.exists(association_path):
            logging.error("Association folder not found.")
            return jsonify({"message": "Association folder not found."}), 404

        news_folder = os.path.join(association_path, 'news')
        logging.info(f"News folder path: {news_folder}")

        # Check if the news folder exists
        if not os.path.exists(news_folder):
            logging.error("News folder not found.")
            return jsonify({"message": "News folder not found."}), 404

        # Construct the full path of the image to be deleted
        image_path = os.path.join(news_folder, image_name)
        logging.info(f"Image path: {image_path}")

        # Check if the image exists
        if not os.path.isfile(image_path):
            logging.error("Image not found.")
            return jsonify({"message": "Image not found."}), 404

        # Delete the image
        os.remove(image_path)
        logging.info(f"Deleted image: {image_path}")

        # Rename remaining images if needed
        existing_images = sorted([f for f in os.listdir(news_folder) if f.startswith('news') and f.endswith(('.png', '.jpg', '.jpeg'))])
        for i, existing_image in enumerate(existing_images, start=1):
            new_image_name = f'news{i}.png'
            if existing_image != new_image_name:
                os.rename(os.path.join(news_folder, existing_image), os.path.join(news_folder, new_image_name))
                logging.info(f"Renamed image {existing_image} to {new_image_name}")

        return jsonify({"message": "Image deleted successfully."}), 200

    except Exception as e:
        logging.error("An error occurred during image deletion:")
        logging.error(traceback.format_exc())
        return jsonify({"message": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        conn.close()

