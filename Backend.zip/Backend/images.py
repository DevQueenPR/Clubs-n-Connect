from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
from PIL import Image  # Import Pillow's Image module

app = Flask(__name__)
CORS(app)

# Define the upload folder
UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def create_folder():
    data = request.json
    folder_name = data.get('folder_name')
    
    if not folder_name:
        return jsonify({"error": "Folder name is required"}), 400
    
    # Set the path to create the folder
    folder_path = os.path.join(app.config['UPLOAD_FOLDER'], folder_name)

    try:
        # Create the folder if it doesn't exist
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
            return jsonify({"message": f"Folder '{folder_name}' created successfully."}), 201
        else:
            return jsonify({"message": f"Folder '{folder_name}' already exists."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def upload_photo():
    # Get the folder name from the request
    folder_name = request.form.get('folder_name')
    
    # Ensure the folder name exists
    if not folder_name:
        return jsonify({"error": "Folder name is required"}), 400
    
    # Create the directory for the folder if it doesn't exist
    folder_path = os.path.join(app.config['UPLOAD_FOLDER'], folder_name)
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    
    # Check if the request contains a file part
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    
    file = request.files['file']
    
    # If no file was selected
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    # Save the file to the desired folder temporarily
    temp_file_path = os.path.join(folder_path, file.filename)
    file.save(temp_file_path)
    
    # Resize the image
    try:
        max_width = 1200  # Max width for the carousel
        max_height = 600  # Max height for the carousel

        # Open the image using Pillow
        with Image.open(temp_file_path) as img:
            # Resize the image while maintaining the aspect ratio
            img.thumbnail((max_width, max_height), Image.LANCZOS)  # Use LANCZOS instead of ANTIALIAS
            # Save the resized image
            img.save(temp_file_path)

    except Exception as e:
        return jsonify({"error": f"Error resizing image: {str(e)}"}), 500
    
    return jsonify({"message": f"File '{file.filename}' uploaded and resized successfully to '{folder_name}'."}), 201
'''
def uploaded_file(folder_name, filename):
    upload_folder = os.path.join(os.getcwd(), 'uploads')  # Set the path to the 'uploads' folder
    folder_path = os.path.join(upload_folder, folder_name)  # Path to the folder inside 'uploads'
    return send_from_directory(folder_path, filename)  # Serve the file from the folder

# Define the route to serve uploaded files
@app.route('/uploads/<folder_name>/<filename>')
def uploadloaded_file_route(folder_name, filename):
    return uploaded_file(folder_name, filename)

'''


def uploaded_file(folder_name, subfolder_name, filename):
    # Construct the full path using the folder name and subfolder name
    upload_folder = os.path.join(os.getcwd(), 'uploads')  # Base upload folder
    folder_path = os.path.join(upload_folder, folder_name, subfolder_name)  # Path to the subfolder
    full_path = os.path.join(folder_path, filename)  # Full path to the file

    # Print the path being accessed for debugging
    print(f"Requested folder_name: {folder_name}")
    print(f"Requested subfolder_name: {subfolder_name}")
    print(f"Requested filename: {filename}")
    print(f"Constructed full path to file: {full_path}")

    # Check if the file exists
    if not os.path.exists(full_path):
        print(f"File not found at: {full_path}")
        return "File not found", 404

    # Serve the file
    return send_from_directory(folder_path, filename)
    
    
    
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
